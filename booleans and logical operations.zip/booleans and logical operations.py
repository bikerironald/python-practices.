"""Working with Booleans and Logical
Operations
Understanding Boolean values and expressions:"""


