# Using F-strings for Formatted Output
name = 'Bikeri'
age = 24
print(f'{name} is {age} years old.')