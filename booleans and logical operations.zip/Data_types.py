# Converting Data Types with int() , float() , and
# str()


user_input = input("Enter a number")
user_number = int(user_input)
result = user_number * 3
print('Twice entered the number:', result)


# Working with Strings
# String Manipulation and Operations:
# String concatenation

first_name = 'ronald'
last_name = 'bikeri'

full_name = first_name + ' ' + last_name
print(full_name)

# String Repetition

print(full_name * 3)

# String Concatenation and Formatting:
# String formatting

name ='Bikeri'
age = 24
greeting_message = 'My name is {} and I am {} years old.'.format
(name, age)
print(greeting_message)

name = "Alice"
age = 30
greeting_message = "My name is {} and I am {} years old.".format(name,
age)
print(greeting_message)