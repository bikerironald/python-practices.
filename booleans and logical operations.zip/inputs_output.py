# # input and Output in Python 
name = "alexa wamuyu"
age = int(2)
years = 2024 - age + 18

print(name + ", you will be 18 years old in the year " + str(years))
output = (2035)

# # input and Output in Python 
name = "alisa wangari"
age = int(2)
years = 2024 - age + 18

print(name + ", you will be 18 years old in the year " + str(years))
output = (2035)





# input and Output in Python

# Getting user input and displaying it
f_name = input('Enter your first name: ')
m_name = input('Enter yout middle name: ')
l_name = input('Enter your last name: ')

print('Hello? ' + f_name + " " + m_name + " " + l_name + ' You will become the rich one day')

# Formatting and Displaying Output with
# print()

age = 25
print("I am", age, "years old.")

